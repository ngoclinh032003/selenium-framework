# Selenium Framework Full CI/CD

Run: mvn clean test